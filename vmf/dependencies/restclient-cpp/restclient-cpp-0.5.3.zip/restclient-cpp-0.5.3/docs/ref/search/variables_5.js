var searchData=
[
  ['headers',['headers',['../struct_rest_client_1_1_connection_1_1_info.html#a8e9c9ad0c74a6e6f5c73ced7306464d1',1,'RestClient::Connection::Info::headers()'],['../struct_rest_client_1_1_response.html#a2141b4d9929e0df26d918dfba8451496',1,'RestClient::Response::headers()']]]
];

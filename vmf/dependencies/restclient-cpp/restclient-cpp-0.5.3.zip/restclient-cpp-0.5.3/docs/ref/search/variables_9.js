var searchData=
[
  ['redirectcount',['redirectCount',['../struct_rest_client_1_1_connection_1_1_request_info.html#ab0240290fa51b11468936199ff0c248f',1,'RestClient::Connection::RequestInfo']]],
  ['redirecttime',['redirectTime',['../struct_rest_client_1_1_connection_1_1_request_info.html#af219b63ad58cb52748ba7afd5b2290aa',1,'RestClient::Connection::RequestInfo']]]
];
